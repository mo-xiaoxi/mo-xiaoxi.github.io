#! /bin/bash

cd ~/go/src/gotsctf2018
~/go/bin/bee run
